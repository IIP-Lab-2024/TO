from topy import create_2d_msh

create_2d_msh(8, 4, 'mesh1')