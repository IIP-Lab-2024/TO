# Documents

The docs folder currently only contains my master's dissertation since
ToPy was part of it. The maths behind topology optimization is explained in it.
There is also quite a bit about ToPy in it, but now a little outdated.
The persistent URL for the dissertation is: http://hdl.handle.net/10019.1/2648

Other useful documentation pertaining to ToPy and/or topology optimisation
can be added to this folder.

