
## Scripts

### optimise.py
Use optimise.py to read and solve TPD files.
