import numpy as np
import matplotlib.pyplot as plt


path1 = 'simply-supported-beam_64_128/163585.npz'
data = np.load(path1)
data = data['arr_0']
print (data.shape)
x=data[0]
print (data[0])
print (data[-1])
plt.imshow(data[0],cmap='Greys')
plt.show()
plt.imshow(data[-1],cmap='Greys')
plt.show()


